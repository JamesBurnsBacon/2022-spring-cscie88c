package org.cscie88c.week6

import org.cscie88c.testutils.{ StandardTest }

class AddableTraitTest extends StandardTest {

  // "plus" should {

  //   "add two MyInt values correctly" in {
  //     // add your unit tests for MyInt below
  //   }

  //   "add two MyBool values correctly" in {
  //     // add your unit tests for MyBool below
  //   }
  //  } 
}
