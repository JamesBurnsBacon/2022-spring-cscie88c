package org.cscie88c.week6

import org.cscie88c.testutils.{ StandardTest }

class EmployeeTest extends StandardTest {
  // "Employee" should {
 
  //   "have a default sort order" in {
  //     // write unit tests here
  //   }

  //   "sort employees by salary" in {
  //     // write unit tests here
  //   }
  // }
}
