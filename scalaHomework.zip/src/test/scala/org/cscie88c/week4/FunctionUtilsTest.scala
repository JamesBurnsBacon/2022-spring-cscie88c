package org.cscie88c.week4

import org.cscie88c.testutils.{StandardTest}

class FunctionUtilsTest extends StandardTest {

  //  "FunctionUtils" when {
  //   "calling applyNtimes" should {
  //     "return the correct value" in {
  //       // write unit test here
  //     }
    
  //   }

  //   // write unit tests for other functions here
  // }
 
}
