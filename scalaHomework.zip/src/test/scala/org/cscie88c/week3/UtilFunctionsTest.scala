package org.cscie88c.week3

import org.cscie88c.testutils.{ StandardTest }
import org.scalatest.funsuite.AnyFunSuite
import org.scalatest.matchers.should.Matchers
import org.scalatestplus.scalacheck.ScalaCheckPropertyChecks
import org.scalacheck._

<<<<<<< Updated upstream
class UtilFunctionsTest extends StandardTest {
  // "UtilFunctions" when {
  //   "with pythTriplesUpto100" should {
  //     "verify elements in list are pythagorean triples" in {
  //       // write your test here
  //     }
  //   }
  // }
}
=======
// class UtilFunctionsTest
//     extends AnyFunSuite
//        with Matchers
//        with ScalaCheckPropertyChecks {

//     val detuple: (_,_,_) = {case (a,b,c) => }
//     test("verify elements in pythTriplesUpTo100 are pythagorean triples") {
//         UtilFunctions.pythTriplesUpto100.map(UtilFunctions.pythTest) should all be (true)
//         // val trips = (UtilFunctions.pythTriplesUpto100) 
//         //     for(trips)  { case(a, b, c) =>
//         //     UtilFunctions.pythTest(a,b,c) should be (true)
//         // for(trips <- UtilFunctions.pythTriplesUpto100) { case(a, b, c) =>
//         //     UtilFunctions.pythTest(a,b,c) should be (true)
//     //}
//   }
// }
// class UtilFunctionsTest extends StandardTest {
//   "UtilFunctions" when {
//     "with pythTriplesUpto100" should {
//       "verify elements in list are pythagorean triples" { //removed in
        
//         //UtilFunctions.pythTest(pythTriplesUpto100.sample.get) should be (true)
//         // pythTriplesUpto100 { case(a, b, c) =>
        
//      //
//        // UtilFunctions.pythTest(pythTriplesUpto100[1,1,1]) should be (true)
//       //}
//     }
//   }
// }
>>>>>>> Stashed changes
