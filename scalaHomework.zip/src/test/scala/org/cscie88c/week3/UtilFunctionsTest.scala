package org.cscie88c.week3

import org.cscie88c.testutils.{ StandardTest }

class UtilFunctionsTest extends StandardTest {
  // "UtilFunctions" when {
  //   "with pythTriplesUpto100" should {
  //     "verify elements in list are pythagorean triples" in {
  //       // write your test here
  //     }
  //   }
  // }
}
