package org.cscie88c.week2

import org.cscie88c.testutils.{StandardTest}

// write unit tests for University employee below
class UniversityEmployeeTest extends StandardTest {
  // "UniversityEmployee" when {
  //   "instantiated" should {
  //     "have a name property" in {
  //       true shouldBe true
  //     }
  //   }
  // }
}
