package org.cscie88c.week4

object ListUtils {
  // complete the function below
  def initDoubleList(initValue: Double)(size: Int): List[Double] = ???

  // complete the functions below using currying
  def ones: Int => List[Double] = ???
  def zeros: Int => List[Double] = ???

  // complete the functions below
  def charCounts(sentence: String): Map[Char, Int] = ???

  def topN(n: Int)(frequencies: Map[Char, Int]): Map[Char, Int] = ???

}
