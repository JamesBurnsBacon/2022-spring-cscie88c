package org.cscie88c.week3

object UtilFunctions {
  
  def mult2(x: Int, y: Int): Int = x * y
  
  def pythTest(x: Int, y: Int, z: Int): Boolean = ???

  val pythTriplesUpto100: List[(Int, Int, Int)] = ???

}
