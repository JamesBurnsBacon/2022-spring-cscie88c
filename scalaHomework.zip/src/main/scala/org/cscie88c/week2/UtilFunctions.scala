package org.cscie88c.week2

object UtilFunctions {

  // complete the functions below
  def maximum(a: Int, b: Int): Int = ???
  def average(a: Int, b: Int): Double = ???

}
