package org.cscie88c.week2

object UtilFunctions {

  // complete the functions below
  def maximum(a: Int, b: Int): Int = a.max(b)

  def average(a: Int, b: Int): Double =
    ((a + b).toDouble / 2)

}
