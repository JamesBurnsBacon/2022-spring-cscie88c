package org.cscie88c.week2

// write the class UniversityEmployee below
