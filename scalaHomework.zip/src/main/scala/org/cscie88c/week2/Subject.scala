package org.cscie88c.week2

// complete the definition of the Subject case class and companion object
final case class Subject()

object Subject {
  val allSubjects: List[Subject] = ???

  def stemSubjects: List[Subject] = ???
  
}