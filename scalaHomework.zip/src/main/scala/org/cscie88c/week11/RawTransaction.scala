package org.cscie88c.week11

final case class RawTransaction(
  customer_id: String,
  trans_date: String,
  tran_amount: Double
)