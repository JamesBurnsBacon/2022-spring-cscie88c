package org.cscie88c.week11

final case class RawResponse(
  customer_id: String,
  response: Int
)